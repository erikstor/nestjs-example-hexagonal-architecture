export const SignUpUsersTypes = {
  prop: 'Propietario',
  //'admin': 'Administrador',
  client: 'Cliente',
  employee: 'Empleado',
};
