export const ADMIN_ROLE = 'Administrador';
export const OWNER_ROLE = 'Propietario';
export const CLIENT_ROLE = 'Cliente';
export const EMPLOYEE_ROLE = 'Empleado';
